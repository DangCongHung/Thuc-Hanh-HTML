var randomNum = Math.floor(x:(Math.random() * 10) + 1);
var el = document.getElementById('info');
el.innerHTML = '<h2>radom number</h2><p>' + randomNum + '</p>';